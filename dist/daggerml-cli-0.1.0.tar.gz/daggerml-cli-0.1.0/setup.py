# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['daggerml_cli', 'daggerml_cli.util']

package_data = \
{'': ['*']}

install_requires = \
['PyYAML>=6.0,<7.0',
 'edn-format>=0.7.5,<0.8.0',
 'requests>=2.27.1,<3.0.0',
 'typer[all]>=0.4.0,<0.5.0']

entry_points = \
{'console_scripts': ['daggerml = daggerml_cli.main:app']}

setup_kwargs = {
    'name': 'daggerml-cli',
    'version': '0.1.0',
    'description': '',
    'long_description': '# DaggerML Command Line Tool\n',
    'author': 'Micha Niskin',
    'author_email': 'micha.niskin@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
