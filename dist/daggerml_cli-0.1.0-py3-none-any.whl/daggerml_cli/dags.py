import json
import typer
from typing import List, Optional
from daggerml_cli.util import restapi

app = typer.Typer()

def print_json(x):
    typer.echo(json.dumps(x, indent=2))

@app.command()
def get_nodes():
    """
    Prints nodes to stdout.
    """
    print_json(restapi.get_view("node_view"))

@app.command()
def get_handlers():
    """
    Prints handlers to stdout.
    """
    print_json(restapi.get_view("handler_view"))

@app.command()
def get_executors():
    """
    Prints executors to stdout.
    """
    print_json(restapi.get_view("executor_view"))

@app.command()
def get_dags():
    """
    Prints dags to stdout.
    """
    print_json(restapi.get_view("dag_view"))

@app.command()
def get_queue():
    """
    Prints the node work queue to stdout.
    """
    print_json(restapi.get_view("node_queue"))

if __name__ == "__main__":
    app()
