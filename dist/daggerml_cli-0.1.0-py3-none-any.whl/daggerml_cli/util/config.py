config = {
    'zone': 'prod',
    'region': 'us-west-2'
}
